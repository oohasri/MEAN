// const http = require('http');
// const fs = require('fs');
const express = require('express');
const app = express();
// var path = require ('path');
app.use(express.static(__dirname + "/static"));
app.set('view engine', 'ejs');
app.set('views',__dirname + '/static/views');
app.get('/', (request, response) => {
	response.render('index.html');
});
app.get('/cars', (request, response) => {
	response.render('cars');
});
app.get('/cats', (request, response) => {
	response.render('cats');
});
app.get('/cars/new', (request, response) => {
	response.render('new');
});
app.listen(8000, () => console.log("listening on port 8000"));
